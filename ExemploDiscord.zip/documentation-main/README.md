# BetterDiscord Documentation
Documentation, guidelines and tutorials for BetterDiscord.
[https://betterdiscord.app/docs](https://betterdiscord.app/docs)
